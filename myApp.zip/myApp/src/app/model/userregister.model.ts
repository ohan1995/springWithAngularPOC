export class UserRegisterData {
    username = ''
    email = ''
    password = ''
    city = ''
    country = ''
}