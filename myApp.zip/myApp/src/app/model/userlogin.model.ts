export class UserLoginData {
    public username = '';
    public password = '';
}